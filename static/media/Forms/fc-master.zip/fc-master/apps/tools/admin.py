from django.contrib import admin
from apps.tools.models import *
# Register your models here.


admin.site.register(Busines)
admin.site.register(Menu)
admin.site.register(Alert)
admin.site.register(Calendar)
admin.site.register(Chat)
admin.site.register(Directory)
admin.site.register(Folder)
admin.site.register(File)
