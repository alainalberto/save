from django.apps import AppConfig


class LogisticConfig(AppConfig):
    name = 'logistic'
